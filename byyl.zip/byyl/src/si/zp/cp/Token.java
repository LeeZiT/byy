package si.zp.cp;

public class Token {
	public int nob, line, index, type;
	public String cont, value;

	@Override
	public String toString() {
		return String.format("%03d: [%04d, %04d, %04d, %s]", this.nob, this.line, this.index, 
this.type,
			this.cont.replace("\n", "\\n"));
	}
	public static Token get(int line, int pos, int type, String cont) {
		Token t = new Token();
		t.line = line;
		t.index = pos;
		t.type = type;
		t.cont = cont;
		t.value = cont.replaceAll("\\s+", "");
		return t;
	}
	
	@Override
	public int hashCode() {
		return this.nob;
	}

	@Override
	public boolean equals(Object obj) {
		if (null == obj)
			return false;
		if (this == obj)
			return true;
		if (obj instanceof Token)
			return this.nob == Token.class.cast(obj).nob;
		return false;
	}
}