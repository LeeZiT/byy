package si.zp.cp;

import java.lang.reflect.Method;
import java.util.List;

public abstract class Semantic {
	public Source s;

	public Semantic(Source s) {
		this.s = s;
		this.varCount = 0;
	}
	public void doTranslate(String rule_name, Element left, List<Element> right) {
		try {
			Class<?> cls = this.getClass();
			Method mtd = cls.getMethod(rule_name, Element.class, List.class);
			mtd.invoke(this, left, right);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private int varCount;

	protected String getVariable() {
		this.varCount++;
		return String.format("$T%04X", this.varCount);
	}
}