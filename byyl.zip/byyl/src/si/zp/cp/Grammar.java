package si.zp.cp;
import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
public class Grammar {
public static final int Const_END = 1;
public static final int Const_EPS = 2;
public static final int Const_S_code = 3;
public static final int Const_START = 4;
public static final String Const_S_name = "S";
public Map<String, Integer> TC, NC;
public List<Rule> rules;
public String start;
public Grammar() {
this.TC = new TreeMap<String, Integer>();
this.NC = new TreeMap<String, Integer>();
this.rules = new ArrayList<Rule>();
}
public Grammar(Map<String, Integer> terminals, String Gram, String start) {
this();
this.phrase(terminals, Gram, start);
}
public Grammar extend() {
if (Const_S_name.equals(this.start))
return this;
this.NC.put(Const_S_name, Const_S_code);
String q[] = { this.start };
int nq[] = { Const_START };
this.rules.add(0, new Rule(Const_S_name, q, Const_S_code, nq));
this.start = Const_S_name;
return this;
}
public void phrase(Map<String, Integer> terminals, String Gram, String start) {
this.TC.clear();
this.NC.clear();
this.rules.clear();
this.TC.put("$", Const_END);
this.TC.put("epsilon", Const_EPS);
this.TC.putAll(terminals);
this.start = start;
this.NC.put(this.start, Const_START);
try {
int tc_idx = 5000;
BufferedReader br = new BufferedReader(new StringReader(Gram));
for (String line = br.readLine(); null != line; line = br.readLine()) {
if (line.startsWith("##"))
continue;
if (line.startsWith("&&") && line.trim().length() > 2) {
String sp[] = line.trim().substring(2).split("##");
for (String i : sp)
this.TC.put(i.trim(), ++tc_idx);
continue;
}
String sp[] = line.split("@@");
if (2 != sp.length)
continue;
String p = sp[0].trim();
if (!this.NC.containsKey(p))
this.NC.put(p, Const_START + this.NC.size());
String sq[] = sp[1].split("##");
for (String i : sq) {
String q[] = i.trim().split("\\s+");
int nq[] = new int[q.length];
for (int j = 0; j < q.length; j++) {
String nc = q[j];
if (!(this.TC.containsKey(nc) || this.NC.containsKey(nc)))
this.NC.put(nc, Const_START + this.NC.size());
nq[j] = this.TC.containsKey(nc) ? this.TC.get(nc) : this.NC.get(nc);
}
this.rules.add(new Rule(p, q, this.NC.get(p), nq));
}
}
} catch (Exception e) {
e.printStackTrace();
}
}
public boolean isNC(int code) {
return this.NC.containsValue(code);
}
public boolean isNC(String name) {
return this.NC.containsKey(name);
}
}