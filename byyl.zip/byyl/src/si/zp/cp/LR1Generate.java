package si.zp.cp;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
public class LR1Generate {
public Grammar gram;
public List<List<int[]>> stats; // LR1 ״̬��
public Map<String, int[]> jump; // LR1 ת���� ��������
public LR1Generate() {
this.stats = new ArrayList<List<int[]>>();
this.jump = new TreeMap<String, int[]>();
}
public LR1Generate(Grammar gram) {
this();
this.construct(gram.extend());
System.out.println(String.format("LR(1) Status#: %d, Action#: %d.", this.stats.size(), 
this.jump.size()));
}
public void construct(Grammar gram) {// ���� ������
this.gram = gram;
this.stats.clear();
this.jump.clear();
// ��������������
List<int[]> i0 = new ArrayList<int[]>();
int[] r0 = { 0, 0, Grammar.Const_END }; // rule_idx, accept_idx,
// next_code
i0.add(r0);
this.closure(i0);
this.stats.add(i0);
for (int i = 0; i < this.stats.size(); i++) {
List<int[]> s_1 = this.stats.get(i);
List<Integer> next = this.nextC(s_1);
for (int a : next) {
List<int[]> s_2 = new ArrayList<int[]>();
for (int[] j : s_1)
if (j[1] < this.gram.rules.get(j[0]).nq.length && a ==
this.gram.rules.get(j[0]).nq[j[1]]) {
int[] n_item = { j[0], j[1] + 1, j[2] };
s_2.add(n_item);
}
this.closure(s_2);
int toIdx = this.findStat(s_2);
if (toIdx < 0) {
this.stats.add(s_2);
toIdx = this.stats.size() - 1;
}
String key = i + "-" + a; // ���Ž�ջ����
int[] action = { 1, toIdx };
int[] od_action = this.jump.get(key);
if (null == od_action || action[0] < od_action[0] || action[1] < od_action[1])
this.jump.put(key, action);
if (null != od_action)
System.out.println(String.format("LR(1) M2M: <%s> [%d,%d] [%d,%d]->[%d,%d]", key, 
od_action[0],
od_action[1], action[0], action[1], this.jump.get(key)[0], 
this.jump.get(key)[1]));
}
for (int[] j : s_1)
if (j[1] == this.gram.rules.get(j[0]).nq.length) {
String key = i + "-" + j[2];// ��Լ����
int[] action = { 0, j[0] };
int[] od_action = this.jump.get(key);
if (null == od_action || action[0] < od_action[0] || action[1] < od_action[1])
this.jump.put(key, action);
if (null != od_action)
System.out.println(String.format("LR(1) M2R: <%s> [%d,%d] [%d,%d]->[%d,%d]", 
key, od_action[0],
od_action[1], action[0], action[1], this.jump.get(key)[0], 
this.jump.get(key)[1]));
}
}
int[] acc = { 2, 0 };
this.jump.put(1 + "-" + Grammar.Const_END, acc);
}
private int findStat(List<int[]> s) {
for (int i = 0; i < this.stats.size(); i++) {
List<int[]> o = this.stats.get(i);
if (s.size() != o.size())
continue;
int find = 0;
for (int[] j : o)
for (int[] k : s)
if (j[0] == k[0] && j[1] == k[1] && j[2] == k[2]) {
find++;
break;
}
if (find == o.size() && find == s.size())
return i;
}
return -1;
}
private List<Integer> nextC(List<int[]> s) {
List<Integer> next = new LinkedList<Integer>();
for (int[] i : s) {
Rule r = this.gram.rules.get(i[0]);
if (i[1] < r.nq.length && (!next.contains(r.nq[i[1]]))) {
next.add(r.nq[i[1]]);
}
}
return next;
}
private List<int[]> closure(List<int[]> s) {
for (int i = 0; i < s.size(); i++) {
int[] item = s.get(i);
Rule r0 = this.gram.rules.get(item[0]);
if (item[1] < r0.nq.length) {
int code = r0.nq[item[1]];
if (this.gram.isNC(code)) {
for (int j = 0; j < this.gram.rules.size(); j++) {
Rule r1 = this.gram.rules.get(j);
if (r1.np == code) {
Set<Integer> set = this.first(r0.nq, item[1] + 1, item[2]);
for (int fst : set) {
int[] r_n = { j, 0, fst };
if (!this.isContain(s, r_n))
s.add(r_n);
}
}
}
}
}
}
return s;
}
private boolean isContain(List<int[]> lst, int[] item) {
for (int[] i : lst)
if (item[0] == i[0] && item[1] == i[1] && item[2] == i[2])
return true;
return false;
}
private Set<Integer> first(int[] nq, int idx, int a) {
Set<Integer> res = new TreeSet<Integer>();
this.calFirst(res, nq, idx, a);
if (res.contains(Grammar.Const_EPS)) {
res.add(a);
res.remove(Grammar.Const_EPS);
}
return res;
}
private void calFirst(Set<Integer> set, int[] nq, int idx, int a) {
if (idx >= nq.length) {
set.add(a);
return;
}
if (!this.gram.isNC(nq[idx]))
if (nq[idx] == Grammar.Const_EPS) {
calFirst(set, nq, idx + 1, a);
return;
} else {
set.add(nq[idx]);
return;
}
this.searchFirst(nq[idx], set, new TreeSet<Integer>());
}
private void searchFirst(int code, Set<Integer> set, Set<Integer> path) {
if (path.contains(code))
return;
path.add(code);
for (Rule i : this.gram.rules)
if (code == i.np && i.nq.length > 0) {
if (this.gram.isNC(i.nq[0])) {
this.searchFirst(i.nq[0], set, path);
} else {
set.add(i.nq[0]);
}
}
}
}