package si.zp.cp;

public class Directive {
	public String name, op1, op2, result;

	public Directive(String name, String op1, String op2, String result) {
		this.name = name;
		this.op1 = op1;
		this.op2 = op2;
		this.result = result;
	}
	public static Directive getDirective(String name, String op1, String op2, String result) {
		return new Directive(name, op1, op2, result);
	}
}