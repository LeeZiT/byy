package si.zp.cp;
import java.util.Map;
import java.util.TreeMap;
public class LexAnalysis {
public static Source run(Source target) {
LexAnalysis.analysis(target);
LexAnalysis.updateIdType(target);
return target;
}
private static void analysis(Source target) {
String code = target.code;
int line = 1;
for (int i = 0; i < code.length();) {
char ch = code.charAt(i);
if (Words.isBlank(ch)) {
i++;
if (ch == '\n')
line++;
continue;
}
if (Words.isLetter(ch)) {
String t = "";
do {
t = t + ch;
ch = code.charAt(++i);
} while (Words.isLetter(ch) || Words.isDigital(ch));
if (Words.terminals.containsKey(t)) {
target.addToken(line, i, Words.terminals.get(t), t);
} else {
target.addToken(line, i, Words.id, t);
}
continue;
}
if (Words.isDigital(ch) || '.' == ch) {
String number = "";
if (Words.isDigital(ch)) {
do {
number = number + ch;
ch = code.charAt(++i);
} while (Words.isDigital(ch));
}
if ('.' != ch) {
target.addToken(line, i, Words.number_int, number);
} else {
do {
number = number + ch;
ch = code.charAt(++i);
} while (Words.isDigital(ch));
target.addToken(line, i, Words.number_real, number);
}
continue;
}
switch (ch) {
case '/':
if (code.charAt(i + 1) != '/' && code.charAt(i + 1) != '*')
target.addToken(line, ++i, Words.terminals.get(ch + ""), ch + "");
else if (code.charAt(i + 1) == '/') {
String comments = "";
do {
comments = comments + ch;
ch = code.charAt(++i);
} while (ch != '\n');
target.addToken(line, i, Words.comments, comments);
} else if (code.charAt(i + 1) == '*') {
String comments = "";
do {
comments = comments + ch;
if (ch == '\n')
line++;
ch = code.charAt(++i);
} while (!(code.charAt(i - 1) == '/' && code.charAt(i - 2) == '*'));
target.addToken(line, i, Words.comments, comments);
}
break;
case '&': // ������ͬ��
case '|':
if (code.charAt(i + 1) == ch) {
i += 2;
target.addToken(line, i, Words.terminals.get(ch + "" + ch), ch + "" + ch);
break;
}
case '=': // ������Խ�=
case '>':
case '<':
case '!':
if (code.charAt(i + 1) == '=') {
i += 2;
target.addToken(line, i, Words.terminals.get(ch + "="), ch + "=");
break;
}
default:
if (Words.terminals.containsKey(ch + "")) {
target.addToken(line, ++i, Words.terminals.get(ch + ""), ch + "");
} else {
target.addToken(line, ++i, Words.unknown, ch + "");
}
}
}
}
private static void updateIdType(Source target) {
Map<String, Integer> id2type = new TreeMap<String, Integer>();
int type = -1;
for (Token i : target.tokens) {
if (i.type == Words.id && id2type.containsKey(i.cont)) {
i.type = id2type.get(i.cont);
} else if (i.type == Words.terminals.get("int")) {
type = Words.id_int;
} else if (i.type == Words.terminals.get("real")) {
type = Words.id_real;
} else if (i.type == Words.terminals.get("bool")) {
type = Words.id_bool;
} else if (i.type == Words.terminals.get(";")) {
type = -1;
} else if (i.type == Words.id && type > -1) {
i.type = type;
id2type.put(i.cont, i.type);
}
}
}
}