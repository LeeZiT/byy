package si.zp.cp;
public class Rule {
public String p, q[]; // p -> q[1]q[2]... ������������
public int np, nq[]; // np -> nq[1]nq[2]... ����ת��Ϊ������ʽ
/**
* �����캯��
* 
* @param p �Ƶ�ǰ��
* @param q �Ƶ����
* @param np ת����ǰ��
* @param nq ת������
*/
public Rule(String p, String[] q, int np, int[] nq) {
if (null != p && null != q) {
this.p = p;
this.q = q;
this.np = np;
this.nq = nq;
} else {
this.p = null;
this.q = null;
this.np = -1;
this.nq = null;
}
}
@Override
public boolean equals(Object obj) {
if (null == obj)
return false;
if (this == obj)
return true;
if (obj instanceof Rule) {
Rule r = Rule.class.cast(obj);
if (this.p != r.p && (!this.p.equals(r.p)))
return false;
if (this.q != r.q && this.q.length != r.q.length)
return false;
for (int i = 0; i < this.q.length; i++)
if (!this.q[i].equals(r.q[i]))
return false;
return true;
}
return super.equals(obj);
}
@Override
public int hashCode() {
return this.toString().hashCode();
}
@Override
public String toString() {
String s = this.p + "@@";
for (int i = 0; i < this.q.length; i++)
s = s + q[i] + "##";
return s.substring(0, s.length() - 2);
}
}