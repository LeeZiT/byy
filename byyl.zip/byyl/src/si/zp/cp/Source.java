package si.zp.cp;

import java.util.ArrayList;
import java.util.List;

public class Source {
	public String code;
	public List<Token> tokens;
	public List<Directive> runlist;
	
	public Source() {
		this.tokens = new ArrayList<Token>();
		this.runlist = new ArrayList<Directive>();
	}

	public Source(String code) {
		this();
		this.code = code;
	}

	public void addToken(Token t) {
		t.nob = this.tokens.size() + 1;
		this.tokens.add(t);
	}

	public void addToken(int line, int pos, int type, String cont) {
		this.addToken(Token.get(line, pos, type, cont));
	}

	public void addDirective(Directive d) {
		this.runlist.add(d);
	}

	public void addDirective(String name, String op1, String op2, String result) {
		this.addDirective(Directive.getDirective(name, op1, op2, result));
	}
}