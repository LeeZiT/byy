package si.zp.cp;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.TreeMap;

public class Words {
	public static final Map<String, Integer> terminals = new TreeMap<String, Integer>();
	public static final Map<String, Integer> terminals_all = new TreeMap<String, Integer>();
	public static final int unknown = -1;
	public static final int comments = 0;
	public static final int id = 4001;
	public static final int number_int = 4002;
	public static final int number_real = 4003;
	// public static final int bool = 4004;
	public static final int id_int = 4005;
	public static final int id_real = 4006;
	public static final int id_bool = 4007;
	
	static {
			terminals.put("main", 1001);
				terminals.put("if", 1002);
				terminals.put("else", 1003);
				terminals.put("while", 1004);
				terminals.put("int", 1005);
				terminals.put("real", 1006);
				terminals.put("bool", 1007);
				terminals.put("true", 1008);
				terminals.put("false", 1009);
				terminals.put("return", 1010);
				terminals.put("print", 1011);
				
				terminals.put("+", 2001);
				terminals.put("-", 2002);
				terminals.put("*", 2003);
				terminals.put("/", 2004);
				terminals.put("%", 2005);
				terminals.put(">", 2006);
				terminals.put("<", 2007);
				terminals.put(">=", 2008);
				terminals.put("<=", 2009);
				terminals.put("==", 2010);
				terminals.put("!=", 2011);
				terminals.put("=", 2012);
				terminals.put("||", 2013);
				terminals.put("&&", 2014);
				terminals.put("!", 2015);
				
				terminals.put(";", 3001);
				terminals.put(",", 3002);
				terminals.put("(", 3003);
				terminals.put(")", 3004);
				terminals.put("{", 3005);
				terminals.put("}", 3006);
				terminals.put("[", 3007);
				terminals.put("]", 3008);
				
				terminals_all.putAll(terminals);
				terminals_all.put("id", Words.id);
				terminals_all.put("id_int", Words.id_int);
				terminals_all.put("id_real", Words.id_real);
				terminals_all.put("id_bool", Words.id_bool);
				terminals_all.put("value_int", Words.number_int);
				terminals_all.put("value_real", Words.number_real);
	}
	public static boolean isLetter(char c) {
			return ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z');
	}
	public static boolean isBlank(char c) {
			return c == ' ' || c == '\t' || c == '\r' || c == '\n';
	}
	public static boolean isDigital(char c) {
		return '0' <= c && c <= '9';
	}
	public static String readSample(String path) {
		StringBuffer sb = new StringBuffer();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
			for (String i = br.readLine(); null != i; i = br.readLine())
				sb.append(i + "\n");
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
}