package si.zp.cp;
import java.util.List;
public class Calculate extends Semantic {
public Calculate(Source s) {
super(s);
}
public void r1(Element left, List<Element> right) {
left.value = this.getVariable();
s.addDirective("add", right.get(0).value, right.get(2).value, left.value);
}
public void r2(Element left, List<Element> right) {
left.value = right.get(0).value;
}
public void r3(Element left, List<Element> right) {
left.value = this.getVariable();
s.addDirective("mul", right.get(0).value, right.get(2).value, left.value);
}
public void r4(Element left, List<Element> right) {
left.value = right.get(0).value;
}
public void r5(Element left, List<Element> right) {
left.value = right.get(1).value;
}
public void r6(Element left, List<Element> right) {
left.value = right.get(0).symbol;
}
}