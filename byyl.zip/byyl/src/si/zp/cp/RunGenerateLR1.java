package si.zp.cp;
public class RunGenerateLR1 {
public static void main(String[] argc) {
String gramText = Words.readSample("text/Gamma.txt");
Grammar gram = new Grammar(Words.terminals, gramText, "Gamma");
gram.extend();
System.out.println("���й�����Ϣ:");
for (int i = 0; i < gram.rules.size(); i++)
System.out.println(String.format("r%d %s", i, gram.rules.get(i)));
System.out.println("\n ��ʼ���� LR ������:");
LR1Generate lr1 = new LR1Generate(
new Grammar(Words.terminals_all, Words.readSample("text/Gamma.txt"), "Gamma"));
System.out.println("\n ������:");
String[] action = { "R", "S", "Acc" };
for (String i : lr1.jump.keySet()) {
String[] a = i.split("-");
System.out.println(a[0] + "##" + findTC(Integer.parseInt(a[1])) + "\t" +
action[lr1.jump.get(i)[0]]
+ (lr1.jump.get(i)[0] != 2 ? lr1.jump.get(i)[1] : ""));
}
}
public static String findTC(int num) {
if (num == Grammar.Const_END)
return "$";
if (num == Grammar.Const_START)
return Grammar.Const_S_name;
for (String i : Words.terminals_all.keySet())
if (num == Words.terminals_all.get(i))
return i;
return "" + num;
}
}